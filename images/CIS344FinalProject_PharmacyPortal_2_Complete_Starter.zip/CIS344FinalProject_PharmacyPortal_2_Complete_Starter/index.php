<?php
/** CIS 344 entry point */
require_once __DIR__ . '/PharmacyServer.php';
