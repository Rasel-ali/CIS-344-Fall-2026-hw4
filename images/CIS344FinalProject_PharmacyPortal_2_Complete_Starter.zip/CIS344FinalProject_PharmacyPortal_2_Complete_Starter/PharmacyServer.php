<?php
/**
 * CIS 344 — Pharmacy Portal 2.0 (STUDENT STARTER)
 * Controller / routing layer. Complete the marked TODO actions.
 * The original project's templates are NOT included in these two PHP files.
 * Keep or create the referenced templates as part of your implementation.
 */
require_once __DIR__ . '/PharmacyDatabase.php';

class PharmacyPortal
{
    private PharmacyDatabase $db;

    public function __construct()
    {
        $this->db = new PharmacyDatabase();
    }

    public function handleRequest(): void
    {
        $action = $_GET['action'] ?? 'home';
        try {
            switch ($action) {
                case 'addPrescription':
                    $this->addPrescription();
                    break;
                case 'viewPrescription':
                    $this->viewPrescriptions();
                    break;
                case 'viewInventory':
                    $this->viewInventory();
                    break;
                case 'addUser':
                    $this->addUser();
                    break;
                case 'patientHistory':
                    $this->patientHistory();
                    break;
                case 'lowStock':
                    $this->lowStock();
                    break;
                case 'processSale':
                    $this->processSale();
                    break;
                default:
                    $this->home();
            }
        } catch (Throwable $error) {
            // Starter-only error handler. Students should avoid displaying
            // sensitive DB details in production and implement user-friendly errors.
            http_response_code(500);
            error_log($error->getMessage());
            echo 'Unable to complete the request. Check the application log.';
        }
    }

    /** WORKING EXAMPLE: include the homepage template. */
    private function home(): void
    {
        include __DIR__ . '/templates/home.php';
    }

    /** WORKING EXAMPLE: call a DB method and pass rows to a template. */
    private function viewPrescriptions(): void
    {
        $prescriptions = $this->db->getAllPrescriptions();
        include __DIR__ . '/templates/viewPrescription.php';
    }

    /** PARTIAL EXAMPLE: validation + routing provided; DB insert is student work. */
    private function addPrescription(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            include __DIR__ . '/templates/addPrescription.php';
            return;
        }

        $patientUserName = trim((string) ($_POST['patient_username'] ?? ''));
        $medicationId = filter_var($_POST['medication_id'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($_POST['quantity'] ?? null, FILTER_VALIDATE_INT);
        $instructions = trim((string) ($_POST['dosage_instructions'] ?? ''));

        if ($patientUserName === '' || $medicationId === false || $medicationId < 1
            || $quantity === false || $quantity < 1) {
            http_response_code(400);
            echo 'Provide a patient username, valid medication ID, and positive quantity.';
            return;
        }

        // TODO: Complete PharmacyDatabase::addPrescription() so this works.
        $this->db->addPrescription($patientUserName, $medicationId, $instructions, $quantity);
        header('Location: index.php?action=viewPrescription');
        exit;
    }

    /** STUDENT TASK: finish each route and create the corresponding template. */
    private function viewInventory(): void
    {
        // TODO: Call medicationInventory() and display inventory rows.
        throw new LogicException('TODO: implement viewInventory()');
    }

    private function addUser(): void
    {
        // TODO: Handle GET form + POST validation + addUser() + redirect.
        throw new LogicException('TODO: implement addUser() controller');
    }

    private function patientHistory(): void
    {
        // TODO: Validate patient ID, call getPatientPrescriptionHistory(), display results.
        throw new LogicException('TODO: implement patientHistory()');
    }

    private function lowStock(): void
    {
        // TODO: Validate threshold, call getLowStockMedications(), display results.
        throw new LogicException('TODO: implement lowStock()');
    }

    private function processSale(): void
    {
        // TODO: Handle GET form + POST validation; call processSale().
        // TODO: Show success/failure and demonstrate insufficient-stock rollback.
        throw new LogicException('TODO: implement processSale() controller');
    }
}

$portal = new PharmacyPortal();
$portal->handleRequest();
