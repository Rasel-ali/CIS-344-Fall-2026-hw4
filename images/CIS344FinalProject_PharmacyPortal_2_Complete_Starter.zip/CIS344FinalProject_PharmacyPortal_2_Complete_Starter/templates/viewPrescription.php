<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>All Prescriptions | Pharmacy Portal 2.0</title>
</head>

<body>
    <header>
        <h1>All Prescriptions</h1>
        <nav><a href="index.php">Home</a> | <a href="index.php?action=addPrescription">Add Prescription</a> | <a
                href="index.php?action=viewPrescription">View Prescriptions</a> | <a
                href="index.php?action=viewInventory">Inventory</a></nav>
    </header>
    <main><?php /* WORKING EXAMPLE: the controller provides $prescriptions. */ ?>
        <table border="1" cellpadding="6">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient ID</th>
                    <th>Medication ID</th>
                    <th>Medication</th>
                    <th>Date</th>
                    <th>Instructions</th>
                    <th>Quantity</th>
                    <th>Refills</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (($prescriptions ?? []) as $p): ?>
                    <tr>
                        <?php foreach (['prescriptionId', 'userId', 'medicationId', 'medicationName', 'prescribedDate', 'dosageInstructions', 'quantity', 'refillCount'] as $field): ?>
                            <td><?= htmlspecialchars((string) ($p[$field] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                        <?php endforeach; ?>
                    </tr><?php endforeach; ?>
            </tbody>
        </table><?php if (empty($prescriptions)): ?>
            <p>No prescriptions found.</p><?php endif; ?>
    </main>
</body>

</html>