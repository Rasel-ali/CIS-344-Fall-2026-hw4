<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Add Prescription | Pharmacy Portal 2.0</title>
</head>

<body>
    <header>
        <h1>Add Prescription</h1>
        <nav><a href="index.php">Home</a> | <a href="index.php?action=addPrescription">Add Prescription</a> | <a
                href="index.php?action=viewPrescription">View Prescriptions</a> | <a
                href="index.php?action=viewInventory">Inventory</a></nav>
    </header>
    <main>
        <form method="post" action="index.php?action=addPrescription">
            <label>Patient username <input name="patient_username" required maxlength="45"></label>
            <p></p>
            <label>Medication ID <input type="number" name="medication_id" min="1" required></label>
            <p></p>
            <label>Dosage instructions <textarea name="dosage_instructions" maxlength="200"></textarea></label>
            <p></p>
            <label>Quantity <input type="number" name="quantity" min="1" required></label>
            <p></p>
            <button type="submit">Add Prescription</button>
        </form>
        <p>The database insertion method is a student TODO.</p>
    </main>
</body>

</html>