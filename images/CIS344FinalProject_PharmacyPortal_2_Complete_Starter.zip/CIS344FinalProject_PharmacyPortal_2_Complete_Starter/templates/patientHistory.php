<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Patient History — Student TODO | Pharmacy Portal 2.0</title>
</head>

<body>
    <header>
        <h1>Patient History — Student TODO</h1>
        <nav><a href="index.php">Home</a> | <a href="index.php?action=addPrescription">Add Prescription</a> | <a
                href="index.php?action=viewPrescription">View Prescriptions</a> | <a
                href="index.php?action=viewInventory">Inventory</a></nav>
    </header>
    <main>
        <form method="get" action="index.php"><input type="hidden" name="action" value="patientHistory">
            <label>Patient ID <input type="number" name="patient_id" min="1" required></label><button
                type="submit">Search</button>
        </form>
        <p>TODO: Controller validates patient_id, queries the database, and displays the patient's prescriptions.</p>
    </main>
</body>

</html>