<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Add User — Student TODO | Pharmacy Portal 2.0</title>
</head>

<body>
    <header>
        <h1>Add User — Student TODO</h1>
        <nav><a href="index.php">Home</a> | <a href="index.php?action=addPrescription">Add Prescription</a> | <a
                href="index.php?action=viewPrescription">View Prescriptions</a> | <a
                href="index.php?action=viewInventory">Inventory</a></nav>
    </header>
    <main><?php /* TODO: Wire GET/POST behavior in PharmacyServer::addUser(). */ ?>
        <form method="post" action="index.php?action=addUser">
            <label>Username <input name="user_name" required></label>
            <p></p>
            <label>Contact <input name="contact_info"></label>
            <p></p>
            <label>Role <select name="user_type">
                    <option value="patient">Patient</option>
                    <option value="pharmacist">Pharmacist</option>
                </select></label>
            <p></p>
            <button type="submit">Create User</button>
        </form>
        <p>TODO: Validate inputs, call database method, and display result.</p>
    </main>
</body>

</html>