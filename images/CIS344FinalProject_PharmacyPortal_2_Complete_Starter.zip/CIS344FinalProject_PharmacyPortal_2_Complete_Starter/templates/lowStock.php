<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Low Stock — Student TODO | Pharmacy Portal 2.0</title>
</head>

<body>
    <header>
        <h1>Low Stock — Student TODO</h1>
        <nav><a href="index.php">Home</a> | <a href="index.php?action=addPrescription">Add Prescription</a> | <a
                href="index.php?action=viewPrescription">View Prescriptions</a> | <a
                href="index.php?action=viewInventory">Inventory</a></nav>
    </header>
    <main>
        <form method="get" action="index.php"><input type="hidden" name="action" value="lowStock">
            <label>Threshold <input type="number" name="threshold" min="0" value="10" required></label><button
                type="submit">Show</button>
        </form>
        <p>TODO: Display results from getLowStockMedications().</p>
    </main>
</body>

</html>