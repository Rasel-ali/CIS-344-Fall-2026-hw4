<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Pharmacy Portal 2.0 | Pharmacy Portal 2.0</title>
</head>

<body>
    <header>
        <h1>Pharmacy Portal 2.0</h1>
        <nav><a href="index.php">Home</a> | <a href="index.php?action=addPrescription">Add Prescription</a> | <a
                href="index.php?action=viewPrescription">View Prescriptions</a> | <a
                href="index.php?action=viewInventory">Inventory</a></nav>
    </header>
    <main>
        <p>CIS 344 student starter. Complete the TODO functionality in the database and controller classes.</p>
        <ul>
            <li><a href="index.php?action=addUser">Add User (TODO)</a></li>
            <li><a href="index.php?action=addPrescription">Add Prescription (partial)</a></li>
            <li><a href="index.php?action=viewPrescription">View Prescriptions (example)</a></li>
            <li><a href="index.php?action=viewInventory">View Inventory (TODO)</a></li>
            <li><a href="index.php?action=patientHistory">Patient History (TODO)</a></li>
            <li><a href="index.php?action=lowStock">Low Stock (TODO)</a></li>
            <li><a href="index.php?action=processSale">Process Sale (TODO)</a></li>
        </ul>
    </main>
</body>

</html>