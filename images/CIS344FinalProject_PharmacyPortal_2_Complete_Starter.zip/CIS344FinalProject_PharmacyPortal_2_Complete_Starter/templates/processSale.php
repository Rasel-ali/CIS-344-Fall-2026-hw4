<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Process Sale — Student TODO | Pharmacy Portal 2.0</title>
</head>

<body>
    <header>
        <h1>Process Sale — Student TODO</h1>
        <nav><a href="index.php">Home</a> | <a href="index.php?action=addPrescription">Add Prescription</a> | <a
                href="index.php?action=viewPrescription">View Prescriptions</a> | <a
                href="index.php?action=viewInventory">Inventory</a></nav>
    </header>
    <main>
        <form method="post" action="index.php?action=processSale">
            <label>Prescription ID <input type="number" name="prescription_id" min="1" required></label>
            <p></p>
            <label>Quantity sold <input type="number" name="quantity_sold" min="1" required></label>
            <p></p>
            <button type="submit">Process Sale</button>
        </form>
        <p>TODO: Validate, invoke ProcessSale stored procedure, and show success or rollback errors safely.</p>
    </main>
</body>

</html>