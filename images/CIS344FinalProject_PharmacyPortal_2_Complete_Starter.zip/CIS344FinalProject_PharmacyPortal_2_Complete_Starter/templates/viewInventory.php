<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Medication Inventory — Student TODO | Pharmacy Portal 2.0</title>
    </head>
<body>
    <header><h1>Medication Inventory — Student TODO</h1>
        <nav>
            <a href="index.php">Home</a> 
            | <a href="index.php?action=addPrescription">Add Prescription</a> 
            | <a href="index.php?action=viewPrescription">View Prescriptions</a> 
            | <a href="index.php?action=viewInventory">Inventory</a>
        </nav>
    </header>
    <main>
    <?php /* TODO: controller passes $inventory rows from medicationInventory(). */ ?>
        <p>TODO: Display MedicationInventoryView rows in a table. Escape every displayed value.</p>
    </main>
</body>
</html>
