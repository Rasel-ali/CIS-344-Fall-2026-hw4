<?php
/**
 * CIS 344 — Pharmacy Portal 2.0 (STUDENT STARTER)
 * Database access layer. Complete the marked TODO methods.
 * Expected tables: Users, Medications, Prescriptions, Inventory, Sales.
 * Expected view: MedicationInventoryView.
 * Uses the schema from the project handout; no real patient information.
 */
class PharmacyDatabase
{
    private mysqli $connection;

    public function __construct()
    {
        // Set these environment variables, or replace the defaults locally.
        // Never commit real credentials to a public repository.
        $host = getenv('PHARMACY_DB_HOST') ?: 'localhost';
        $port = (int) (getenv('PHARMACY_DB_PORT') ?: 3306);
        $name = getenv('PHARMACY_DB_NAME') ?: 'pharmacy_portal_db';
        $user = getenv('PHARMACY_DB_USER') ?: 'root';
        $password = getenv('PHARMACY_DB_PASSWORD') ?: '';

        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $this->connection = new mysqli($host, $user, $password, $name, $port);
        $this->connection->set_charset('utf8mb4');
    }

    /** WORKING EXAMPLE: retrieve prescriptions and medication names with a JOIN. */
    public function getAllPrescriptions(): array
    {
        $sql = 'SELECT p.prescriptionId, p.userId, p.medicationId,
                       m.medicationName, p.prescribedDate,
                       p.dosageInstructions, p.quantity, p.refillCount
                FROM Prescriptions AS p
                INNER JOIN Medications AS m ON m.medicationId = p.medicationId
                ORDER BY p.prescribedDate DESC';
        return $this->connection->query($sql)->fetch_all(MYSQLI_ASSOC);
    }

    /** WORKING EXAMPLE: look up a patient safely using a prepared statement. */
    public function findPatientByUsername(string $userName): ?array
    {
        $stmt = $this->connection->prepare(
            "SELECT userId, userName, contactInfo, userType
             FROM Users WHERE userName = ? AND userType = 'patient'"
        );
        $stmt->bind_param('s', $userName);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?: null;
    }

    /** STUDENT TASK 1: complete prescription creation. */
    public function addPrescription(
        string $patientUserName,
        int $medicationId,
        string $dosageInstructions,
        int $quantity
    ): int {
        // TODO: Validate positive quantity and valid medication ID.
        // TODO: Use findPatientByUsername() to locate an existing patient.
        // TODO: Check that the medication exists.
        // TODO: Insert using a prepared statement. Include prescribedDate
        //       (required by the original schema), e.g. NOW().
        // TODO: Return the new prescriptionId. Throw a helpful exception on failure.
        throw new LogicException('TODO: implement addPrescription()');
    }

    /** STUDENT TASK 2: add a user, validating the user type and duplicates. */
    public function addUser(string $userName, string $contactInfo, string $userType): int
    {
        // TODO: Allow only 'patient' or 'pharmacist'.
        // TODO: Reject blank usernames and handle duplicate usernames.
        // TODO: Use a prepared INSERT and return the new userId.
        throw new LogicException('TODO: implement addUser()');
    }

    /** STUDENT TASK 3: query the required database view. */
    public function medicationInventory(): array
    {
        // TODO: SELECT from MedicationInventoryView.
        // TODO: Return an array of associative rows.
        throw new LogicException('TODO: implement medicationInventory()');
    }

    /** STUDENT TASK 4: patient-specific prescription history using JOINs. */
    public function getPatientPrescriptionHistory(int $patientId): array
    {
        // TODO: Query prescriptions for this patient with medication details.
        // TODO: Use a prepared statement and order newest first.
        throw new LogicException('TODO: implement getPatientPrescriptionHistory()');
    }

    /** STUDENT TASK 5: low-stock report with a configurable threshold. */
    public function getLowStockMedications(int $threshold): array
    {
        // TODO: Validate threshold >= 0.
        // TODO: Join Medications with Inventory and filter low stock.
        throw new LogicException('TODO: implement getLowStockMedications()');
    }

    /** STUDENT TASK 6: call a transactional MySQL ProcessSale procedure. */
    public function processSale(int $prescriptionId, int $quantitySold): void
    {
        // TODO: Validate inputs and CALL ProcessSale(?, ?).
        // The stored procedure must atomically record the sale and decrement
        // inventory; insufficient stock must leave both tables unchanged.
        throw new LogicException('TODO: implement processSale()');
    }
}
