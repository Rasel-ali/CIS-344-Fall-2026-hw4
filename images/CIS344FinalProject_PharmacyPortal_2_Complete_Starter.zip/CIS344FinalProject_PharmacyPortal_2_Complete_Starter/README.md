# CIS 344 — Pharmacy Portal 2.0 (Fall 2026)

**Student starter package — PHP, XAMPP, and MySQL/MariaDB**

This project is intentionally incomplete. Complete the required PHP methods, controller actions, SQL objects, and testing described in the instructor's **Final Project Requirements**. Use **fictional** patient and prescription data only.

## 1. Requirements

- XAMPP with **Apache**, **PHP 8+**, and **MySQL/MariaDB** (the XAMPP Control Panel usually labels the database service **MySQL**).
- A browser and a code editor.
- Git and a GitHub account for submission.

## 2. Install and start in XAMPP (Windows)

1. Extract the ZIP and rename the project folder to `PharmacyPortal2`.
2. Move the folder to `C:\xampp\htdocs\PharmacyPortal2\`. The `index.php`, `PharmacyDatabase.php`, `PharmacyServer.php`, and `templates` folder must be directly inside it; avoid an extra nested folder.
3. Open **XAMPP Control Panel** and start **Apache** and **MySQL**.
4. In a browser, open `http://localhost/phpmyadmin/`.
5. Create a database named **`pharmacy_portal_db`**. Create the required tables and database objects according to the project handout; this starter does **not** include a completed SQL script.
6. Review the connection settings in `PharmacyDatabase.php` (see below).
7. Open `http://localhost/PharmacyPortal2/` (or `http://localhost/PharmacyPortal2/index.php`). If Apache uses a nondefault port, include it in the URL, for example `http://localhost:8080/PharmacyPortal2/`.

**Do not open PHP files by double-clicking them or using `file://`.** They must be served by Apache.

## 3. Database configuration

`PharmacyDatabase.php` reads these optional environment variables and uses the following defaults:

| Variable | Default |
| --- | --- |
| `PHARMACY_DB_HOST` | `localhost` |
| `PHARMACY_DB_PORT` | `3306` |
| `PHARMACY_DB_NAME` | `pharmacy_portal_db` |
| `PHARMACY_DB_USER` | `root` |
| `PHARMACY_DB_PASSWORD` | empty string |

For a **local classroom installation only**, students may replace these defaults with their own XAMPP database settings. XAMPP commonly has an empty `root` password initially, but installations vary. **Never publish real credentials to GitHub.** A blank root password is not suitable for a public deployment. If using a different database port, use the port shown in XAMPP configuration. The starter uses `mysqli` and prepared statements.

## 4. Package contents

```text
PharmacyPortal2/
├── index.php                     Application entry point
├── PharmacyDatabase.php          Database class; working examples and TODO methods
├── PharmacyServer.php            Controller/router; working examples and TODO actions
├── README.md
└── templates/
    ├── home.php                  Navigation
    ├── addPrescription.php       Prescription form
    ├── viewPrescription.php      Prescription listing
    ├── addUser.php               Student scaffold
    ├── viewInventory.php         Student scaffold
    ├── patientHistory.php        Student scaffold
    ├── lowStock.php              Student scaffold
    └── processSale.php           Student scaffold
```

## 5. What works and what students must finish

**Provided examples:** Database connection, `getAllPrescriptions()` with a JOIN, `findPatientByUsername()` using a prepared statement, homepage route, prescription listing route, and partial form validation for adding prescriptions.

**Student TODOs in `PharmacyDatabase.php`:** `addPrescription()`, `addUser()`, `medicationInventory()`, `getPatientPrescriptionHistory()`, `getLowStockMedications()`, and `processSale()`.

**Student TODOs in `PharmacyServer.php`:** `viewInventory()`, `addUser()`, `patientHistory()`, `lowStock()`, and `processSale()`. Complete the corresponding template scaffolds and any additional validation or error handling needed.

**SQL work:** Create the required five tables (`Users`, `Medications`, `Prescriptions`, `Inventory`, `Sales`), keys, constraints, stored procedures, views, and trigger specified in the instructor's handout. Ensure sales processing updates inventory atomically and rejects insufficient stock. Follow the current handout if it differs from older project versions.

**Expected at first launch:** The homepage may load after the database connection succeeds. Prescription listing requires the tables to exist. Incomplete features intentionally fail until implemented; this does not mean the starter is a finished application.

## 6. Testing checklist

- Apache and MySQL services are running; homepage opens via `localhost`.
- The application connects to `pharmacy_portal_db`.
- The prescriptions page displays sample rows using the JOIN.
- New users and prescriptions are validated and saved.
- Inventory and patient-history pages show accurate records.
- Low-stock filtering works for a supplied threshold.
- A valid sale updates inventory and records the sale.
- An invalid sale (for example, insufficient inventory) does not partially update records.
- All links, forms, and routes work; errors are handled without exposing credentials.

## 7. Submission

Follow the instructor's current final project handout for the deadline, grading, and presentation details. Submit a GitHub repository containing your completed PHP source, templates, SQL scripts, and a PDF report with screenshots and explanations. Include instructions for running your project in XAMPP. Do not commit real passwords or sensitive personal data. Be prepared to demonstrate the running application and explain your SQL and PHP implementation.

## Troubleshooting

- **404 Not Found:** Confirm the folder is directly under `htdocs` and the URL matches its name.
- **Apache will not start:** Check whether another program is using port 80/443; use the port configured for Apache.
- **Database connection failed:** Start MySQL in XAMPP; check database name, username, password, and port.
- **Table/view not found:** Run your own SQL setup scripts before testing those pages.
- **TODO error:** Implement the indicated student task; it is deliberately incomplete.
- **Blank page or HTTP 500:** Check Apache/PHP error logs and PHP syntax. Do not expose detailed errors on a public deployment.
